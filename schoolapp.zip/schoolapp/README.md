# schoolapp
 Tambah part2
create data
<img src="https://github.com/Syafrizul018/schoolapp/blob/main/create1.jpeg" width="300" height="600">
hasil
<img src="https://github.com/Syafrizul018/schoolapp/blob/main/create.jpeg" width="300" height="600">
