@file:Suppress("UNUSED_EXPRESSION")

package com.example.schoolapp.ui

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.schoolapp.R
import com.example.schoolapp.application.SchoolApp
import com.example.schoolapp.databinding.FragmentSecondBinding
import com.example.schoolapp.model.School

/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class SecondFragment : Fragment() {

    private var _binding: FragmentSecondBinding? = null
    private val binding get() = _binding!!
    private lateinit var applicationContext: Context
    private val schoolViewModel: SchoolViewModel by viewModels {
        SchoolViewModelFactory((applicationContext as SchoolApp).repository)
    }
    private val args : SecondFragmentArgs by navArgs()
    private var school: School? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        applicationContext = requireContext().applicationContext
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentSecondBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        school = args.school
        if (school != null) {
            binding.deleteButton.visibility = View.VISIBLE
            binding.saveButton.text = "Ubah"
            binding.nameEditText.setText(school?.name)
            binding.addressEditText.setText(school?.address)
            binding.streetEditText.setText(school?.street)
        }
        val name = binding.nameEditText.text
        val address = binding.addressEditText.text
        val street = binding.streetEditText.text
        binding.saveButton.setOnClickListener {
            if (name.isEmpty()) {
                Toast.makeText(context, "Nama Tidak Boleh Kosong", Toast.LENGTH_SHORT).show()
            } else if (address.isEmpty()) {
                Toast.makeText(context, "Alamat Tidak Boleh Kosong", Toast.LENGTH_SHORT).show()
            } else if (street.isEmpty()) {
                Toast.makeText(context, "Jalan Tidak Boleh Kosong", Toast.LENGTH_SHORT).show()
            } else{

                if (school == null) {
                    val school = School(0, name.toString(), address.toString(), street.toString())
                    schoolViewModel.insert(school)
                } else {
                    val school = School(school?.id!!, name.toString(), address.toString(), street.toString())
                    schoolViewModel.update(school)
                }
            findNavController().popBackStack()
        }
    }
        binding.deleteButton.setOnClickListener {
            school?.let { schoolViewModel.delete(it) }
            findNavController().popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}