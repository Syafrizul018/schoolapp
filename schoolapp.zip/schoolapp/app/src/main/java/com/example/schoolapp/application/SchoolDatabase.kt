package com.example.sekolahan.application

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.schoolapp.dao.SchoolDao
import com.example.schoolapp.model.School


@Database(entities = [School::class], version = 1, exportSchema = false)
abstract class SchoolDatabase: RoomDatabase(){
    abstract fun schoolDao(): SchoolDao

    companion object{
        private var INSTANCE: SchoolDatabase? = null

        fun getDatabase(context: Context): SchoolDatabase {
            return  INSTANCE ?: synchronized(this){
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SchoolDatabase::class.java,
                    "school_database_1"
                )
                    .allowMainThreadQueries()
                    .build()

                INSTANCE= instance
                instance
            }
        }
    }
}